# Indómito V3: technical handoff

Documento de traspaso para seguir trabajando el sitio en Codex, Claude Code u otra IA.
Estado: septiembre 2026. Owner: Jor Ferraro.

Leer entero antes de tocar nada. Las secciones 2 y 3 (hechos del negocio y reglas de voz) importan tanto como el código. Las versiones anteriores del sitio fallaron porque cada agente rellenó los huecos inventando datos.

---

## 1. Qué es esto

Sitio estático de **Indómito Café** (indomitocafe.com). Reemplaza al sitio actual en Framer.

- **Ubicación:** `/Users/xu/Work/indomito-website/v3/`, dentro del repo `github.com/jorferra/indomito-website`.
- **Stack:** HTML estático generado por `build.mjs` (Node, sin dependencias) desde una fuente única, `content.json`.
- **Deploy previsto:** Cloudflare Workers con static assets (`wrangler.jsonc`).
- **Preview navegable:** artifact privado en claude.ai. Es una sola página con router por hash; se genera en `preview/index.html`.

```
v3/
├── content.json        ← TODO el contenido editable (carta, precios, estados, encuentros, contactos)
├── build.mjs           ← generador: templates de páginas + head SEO + sitemap + redirects + preview
├── wrangler.jsonc      ← config de Cloudflare Workers (assets en ./dist, 404 propio)
├── README.md
├── HANDOFF.md          ← este documento
├── src/
│   ├── styles.css      ← único CSS (tokens, escala tipográfica, temas claro/oscuro)
│   └── img/            ← fotos webp 800/1600, logos, wordmark.svg, og.jpg, favicon
├── preview/index.html  ← generado (no editar a mano)
└── dist/               ← generado (no editar a mano; no está en la carpeta, lo crea el build)
```

**Comandos**

```bash
node build.mjs          # genera dist/ (sitio real) y preview/index.html
npx wrangler deploy     # publica dist/ en Cloudflare (requiere login de wrangler)
```

Para ver el sitio real en local: `cd dist && python3 -m http.server 8000` (las rutas usan barra final: `/carta/`).

---

## 2. Hechos del negocio (no inventar, no contradecir)

- Indómito es un **living a puertas cerradas en Caballito Norte**. No es un café de mostrador:
  - no tiene horarios, local a la calle ni "barra" abierta al público;
  - no tuesta café y no compra café verde;
  - no hay "café de la semana" ni "blend del día".
- El living recibe gente en fechas puntuales, por convocatoria. Ahí se escuchan vinilos y se sirve en tazas de cerámica.
- En el living hay máquina de espresso. En **Sistema Portátil** (el servicio para eventos) el café es **espresso**.
- **Laboratorio Sensorial (LS)** es un método de Jor Ferraro y Andrés Mainetti. Se menciona siempre con esta fórmula exacta:
  > Una experiencia de Laboratorio Sensorial, en colaboración con Indómito Café.
  - Nunca "Laboratorio Sensorial de Indómito" ni "Eventos de LS".
  - La fórmula completa va en la página de cada edición, no repetida en listas.
- **Roles en LS:** Andrés Mainetti guía desde la barra (el costado del café). Jor Ferraro lleva la parte musical e histórica.
- **Diario Sensorial** es una sección dentro del Instagram @indomito_cafe. En el sitio aparece solo como procedencia del **Archivo Sonoro** (sección propia `/archivo-sonoro/`, ver §13). No se usa "Diario Sensorial" como nombre de navegación.
- **Club Sensorial y TRAZA no existen** como producto. No se publican hasta que haya una membresía real.
- **Tienda:** la primera edición está en preparación. No se publican productos inexistentes, precios dummy ni mockups.
- **Música en Sistema Portátil:** curaduría en vivo a cargo de Jor. Sin pedidos (no es un DJ de eventos).
- **Contacto:** WhatsApp +54 9 11 6046 3980 · Instagram @indomito_cafe · LS: @labsensorial.

**Datos falsos conocidos en versiones anteriores (NO reutilizar):**
- tres locales (Pedro Goyena 1420, Nicaragua 4857, Coronel Díaz 2025);
- horarios Lun–Dom;
- "Fundado 2021" y coordenadas GPS;
- equipo inventado (Joaquín Vega, Malena Vitale, etc.);
- "tostamos semanalmente" y "relaciones directas con productores";
- Club a $6.000/mes con 15% de descuento.

Todo esto está en el `CLAUDE.md` y en `src/shared.jsx` de la V1 (ver sección 12).

---

## 3. Voz y reglas editoriales

**Registro:** rioplatense natural, breve y seco, con remates en dos tiempos. La referencia es la voz de las previews V2:
- "El café va donde vos estés."
- "Intenso y directo. Sin concesiones."
- "Lo que pasó y lo que va a pasar."
- "Nos escribís con fecha y formato. Te respondemos, cerramos y vamos."

**Fórmula de redacción:** sustantivo concreto + acción simple + dato útil.

**Evitar:**
- "experiencia inmersiva única", "viaje sensorial", "refugio sensorial", "comunidad vibrante", "redefinimos", "te invitamos a descubrir", "más que una cafetería";
- definir por negación ("No somos una cafetería…", "No es un evento");
- "aún", calcos del inglés y adjetivos de catálogo ("aromas que cuentan historias").

**Frases fijas y dónde viven (no repetir en otros lugares):**

| Frase | Ubicación única |
|---|---|
| Un café no se toma. Se habita. | Origen (lema de cierre) |
| Lo que se siente, no se discute. | Cierre de la página Living |
| Extraemos todo nuestro café a 89 °C. | Carta (dato técnico) y línea chica en la carta de la home |
| Tiempo alrededor de la taza. | Origen |
| Respondemos nosotros, con tiempo. | Footer |

**Reglas que surgieron en la revisión:**
- El H1 es el nombre de la página; la oración va en la bajada (`.lead`).
- No repetir una misma frase en home y página interna, ni dos veces en la misma pantalla.
- "Caballito Norte" aparece solo en el footer, la bajada del hero, la bajada de Origen y junto a una fecha confirmada del living.
- Sin números romanos ni numeraciones decorativas (01/02/03) salvo que el contenido sea una secuencia real (pasos, estaciones).
- **Archivo de encuentros:** se muestra por serie y número ("Tostado & Girado · Edición 001"), no por fecha. La fecha real queda en `fechaReal` para registro interno.
- **Ediciones de LS:** "Edición {Tema}" como título y nombre propio como subtítulo. Nombre completo: "Laboratorio Sensorial: Edición {Tema}".
  - LS01 Edición Electrónica / Entreverde (archivo).
  - LS02 Edición Jamaica / Pressure Bloom (convocatoria abierta).
  - LS03 Edición Tango / Fuelles & Fermento (en preparación).
- **CTA de listas:** siempre "Anotarme por WhatsApp →". Postulaciones a LS: "Postularme →" (formulario de Tally).

---

## 4. Arquitectura

### 4.1 `content.json` (fuente única)

| Clave | Contenido |
|---|---|
| `site` | nombre, URL, zona, WhatsApp, Instagram, año, `umami` (null hasta instalar) |
| `carta` | `vigencia`, `destacados` (3 nombres para la home), `pie`, `notas[]` (la primera se muestra arriba), `categorias[]` con `nombre`, `meta`, `items[]` (`nombre`, `precio` numérico en ARS, `receta`, `nota`) |
| `living` | `estado` (`sin-fecha` o con fecha), `proxima` (`dia`, `horario`, `cupo`), `archivo[]` (`serie`, `titulo`, `nota`, `cafe`, `musica`, `fechaReal`), `frase` |
| `encuentros[]` | `id`, `estado` (`convocatoria` · `proximo` · `preparacion` · `archivo`), `codigo`, `titulo`, `subtitulo`, `nombreCompleto`, `ls` (bool), `fecha` (texto visible), `bajada`, `nota`, `cta` (`label` + `href` externo o `wa` = texto precargado de WhatsApp), `pagina` (bool = tiene página propia) |
| `ls02` | contenido de la página de la Edición Jamaica: `lead2`, `descripcion[]`, `estaciones[]`, `formato[]`, `fechaNota`, `creditos[]` |
| `tienda` | `estado`, `estadoLabel`, `productos[]` (vacío) |

**Comportamientos derivados de los datos:**
- La franja de aviso de la home aparece sola cuando algún encuentro tiene `estado: "convocatoria"`, y desaparece cuando ninguno lo tiene.
- Los precios se formatean con `toLocaleString("es-AR")`.
- Si `site.umami` tiene `{src, id}`, el script de analítica se inyecta en todas las páginas.

### 4.2 `build.mjs`

- `ROUTES`: ruta real y hash de preview por página. `NAV`: menú (Living, Carta, Sistema Portátil, Encuentros, Archivo Sonoro, Origen; Tienda está solo en el footer).
- `ctx(mode)`: `link()` y `src()` resuelven rutas distintas para `dist` (paths absolutos) y `preview` (hashes y `img/` relativo).
- Piezas: `header`, `footer`, `fig` (img con srcset 800/1600, lazy salvo el hero), `pill` (estados), `menuItems`, `encCard`, `aviso`, `WORDMARK` (SVG inline) y `trk()` (atributos de evento para Umami).
- `P.{página}`: `title`, `desc` y `body(x)` de cada página. `P404` es aparte.
- `buildDist()`:
  - escribe una carpeta por ruta con `index.html`, más `404.html`, `styles.css`, `site.js`, `img/`, `robots.txt`, `sitemap.xml` y `_redirects`;
  - cada página lleva meta description, canonical, OG, Twitter card, theme-color y favicon;
  - la home suma además JSON-LD `CafeOrCoffeeShop`.
- `buildPreview()`: todas las páginas como `<div data-page>` en un solo archivo, con el CSS inline y un router por hash. Es el formato que exige el artifact de claude.ai (sin doctype, html, head ni body).

### 4.3 JavaScript (`site.js`)

- **Formulario de Sistema Portátil:**
  - valida que el nombre no esté vacío y, si falta, muestra un error en texto;
  - arma el mensaje de WhatsApp con los 7 campos;
  - muestra la confirmación, dispara `umami.track('consulta-sistema')` si existe y redirige a WhatsApp (solo fuera de un iframe).
- El menú móvil (`<details>`) se cierra al tocar un link.

---

## 5. Sistema visual

**Tokens (`src/styles.css`, `:root`)**

| Token | Claro | Oscuro | Uso |
|---|---|---|---|
| `--bg` | `#ffffff` | `#14120f` | fondo |
| `--ink` | `#16130f` | `#efeae2` | texto |
| `--mute` | `#5c554d` | `#a39b90` | secundario (≥ 4,5:1) |
| `--line` | `#e8e4de` | `#2c2823` | separadores |
| `--soft` | `#f5f3ef` | `#1d1a16` | franja de aviso, caja de confirmación |
| `--amber` | `#8b6f47` | `#c29a66` | **cobre:** todas las etiquetas mono en mayúsculas |

- **Tipografías:**
  - Inter (texto) y JetBrains Mono (etiquetas, precios), ambas desde Google Fonts.
  - El wordmark **INDÓMITO** usa Address Sans Pro Xt Regular (Alejandro Paul, Sudtipos), convertido a paths SVG (`src/img/wordmark.svg`, embebido inline con `currentColor`). La fuente no se sirve.
- **Logo disco:** `disco.png` / `disco-light.png`, a 15 px en el header. Es un detalle sutil, no un protagonista.
- **Escala tipográfica (9 pasos, variables `--fs-*`):**
  - wordmark hero `clamp(64,11vw,156)`;
  - h1 `clamp(48,8vw,104)`, lema `clamp(34,5.2vw,64)`, h2 `clamp(32,4.4vw,52)`, h3 `clamp(22,2.4vw,28)`;
  - lead `clamp(19,1.8vw,21)`, body-l 18, body 17, sm 15, meta 14, label 11 (mono).
  - No agregar tamaños sueltos: usar las variables.
- **Títulos:** un H1 por página; los títulos de sección son `h2.k` (estilo etiqueta cobre).
- **Layout:** columna de 1120 px, gutter de 20 px, secciones separadas por línea fina. La home es un hero tipográfico sin foto más 5 "puertas": Living, Carta, Sistema Portátil, Encuentros y Archivo Sonoro (Encuentros.
- **Accesibilidad aplicada:**
  - contraste AA y objetivos táctiles de 24 px o más;
  - foco visible (outline cobre) y `prefers-reduced-motion`;
  - modo oscuro por `prefers-color-scheme` y `[data-theme]`;
  - `[hidden]{display:none!important}`.

**Fotos en uso:** `carta-granos` (Carta, franja 21:9) y `origen-mano` (Origen). Las demás de `src/img` están disponibles y sin usar.
**Fotos prohibidas:** de terceros (producto Audio-Technica, Edifier, miniaturas de YouTube), mockups de Tienda, tapas de discos en primer plano, fotos de Sistema Portátil que no sean del servicio real, stock e IA.

---

## 6. Páginas

| Ruta | Contenido |
|---|---|
| `/` | Aviso LS02 · hero wordmark · Living · Carta (3 destacados + 89 °C) · Sistema Portátil · Encuentros (estados) |
| `/living/` | Cómo funciona (3 pasos) · próxima apertura (estado) · archivo por edición · cierre "Lo que se siente, no se discute." |
| `/carta/` | Nota de disponibilidad · índice de categorías (solo en dist) · franja de granos · 5 categorías con receta y nota · 89 °C · notas |
| `/sistema-portatil/` | "Indómito se mueve." · ficha (Café, Pastelería, Música, Sonido) · ocasiones (texto) · formulario → WhatsApp (`#consulta`) |
| `/encuentros/` | Próximos (h2) · archivo |
| `/encuentros/edicion-jamaica/` | Estado + Tally · La edición (4 párrafos) · Estaciones · Formato · Créditos |
| `/tienda/` | Estado de lista, sin productos (linkeada solo desde el footer) |
| `/origen/` | Mano · texto de origen · lema |
| `/terminos/`, `404.html` | Legales; 404 con `noindex` |

---

## 7. SEO

**Hecho:**
- títulos con palabra clave por página ("Barra de café para eventos en Buenos Aires — Indómito", etc.);
- descripciones únicas, `lang="es-AR"`, canonical, OG (`/img/og.jpg`, espresso 1200×630);
- JSON-LD en la home, sitemap, robots, alt en imágenes y jerarquía de títulos.

**Redirects (`dist/_redirects`, formato de Cloudflare):**

```
/eventos        /encuentros/ 301
/objetos        /tienda/     301
/club           /encuentros/ 301
/club/tg1       /living/     301
/club/playlists /origen/     301
/terms          /terminos/   301
```

`/news*`, `/page-3`, `/old-home-2`, `/tcvxp` e `/index.php/*` quedan en 404 a propósito. Son restos del template de Framer ("Latte Haven") y de un WordPress anterior que Google todavía tiene indexados.

**Pendiente:**
1. Google Search Console: verificar el dominio, enviar el sitemap y pedir la baja de las URLs del template.
2. Perfil de Google Business como negocio con zona de servicio (Sistema Portátil), sin publicar la dirección del living.
3. JSON-LD `Event` para cada edición de LS cuando tenga `startDate`.
4. Imagen OG por página (hoy todas usan la misma).

---

## 8. Analítica

- **Recomendación:** Umami self-hosted en el servidor Hetzner (Docker, Traefik, Postgres ya existen).
- Cloudflare Web Analytics no sirve para esto porque no registra eventos propios.
- **Instalación en el sitio:** completar `site.umami = { "src": "https://.../script.js", "id": "<website-id>" }` en `content.json` y rebuild.
- **Eventos ya marcados** (`data-umami-event` + `data-umami-event-origen`):
  - `postulacion`: `aviso-home`, `ls02` (lista), `pagina-edicion`;
  - `lista`: `living`, `living-proxima`, `ls03`, `tienda`;
  - `consulta-sistema`: formulario, vía JS con `tipo` y `personas`;
  - `whatsapp` e `instagram`: footer.
- **KPIs mensuales:** consultas de Sistema Portátil por tipo de evento · postulaciones por edición y por origen · altas a listas (living, Tienda).

---

## 9. Deploy

1. Datos cerrados en `content.json` (ver sección 10).
2. `node build.mjs && npx wrangler deploy` desde `v3/`.
3. Apuntar indomitocafe.com a Cloudflare, dar de baja Framer y probar los redirects.

**Ojo:** la V1 (React) y la V2 (HTML) usan el mismo proyecto de Vercel `indomito-website` y el mismo repo. La V3 va a Cloudflare. No publicar V1 ni V2 al dominio.

---

## 10. Pendientes de contenido (bloquean la publicación)

- [ ] Confirmar los precios de la carta y la vigencia (hoy: los del sitio Framer, "Septiembre 2026"). El doble espresso figura a $4.300, igual que el simple: verificar.
- [x] Edición Jamaica: café de Etiopía y cupo de 12 personas, confirmados por Jor el 25 de septiembre de 2026.
- [ ] Mapeo estación ↔ etapa del café en LS02 (no está definido; no inventarlo).
- [ ] Licencia de Address Sans Pro para el wordmark.
- [x] Sistema Portátil sale sin fotos, aprobado por Jor el 25 de septiembre de 2026. Las fotos propias quedan para una actualización posterior y no bloquean la publicación.
- [ ] Umami instalado y `site.umami` completo.
- [ ] Fecha de la próxima apertura del living (hoy "en preparación").

---

## 11. Decisiones tomadas (no revertir sin el OK de Jor)

- Hero sin foto, solo tipografía con el wordmark original.
- Sin fotos en Living ni en Sistema Portátil hasta tener fotos propias.
- Sistema Portátil puede publicarse sin fotos; decisión confirmada por Jor el 25 de septiembre de 2026.
- Tienda fuera del menú y de la home; solo una línea en el footer.
- Aviso fijo en la home mientras haya una convocatoria abierta.
- Sin números romanos.
- Carta con receta (mono) + nota corta en dos tiempos por ítem.
- **Sistema Portátil:**
  - Café "Especialidad. Espresso.";
  - Música "Curaduría en vivo.";
  - Sonido "Equipo propio." (sin modelo ni potencia);
  - sin "Rodajes".
- Origen:
  > Indómito nació en un living de Caballito Norte. / Entre vinilos, cafés, silencios y conversaciones que pedían más tiempo que likes. / Después vino el oficio: moler, medir, esperar. / El punto de partida sigue siendo el mismo: tiempo alrededor de la taza. Lo analógico, lo ritual, lo compartido. / **Un café no se toma. Se habita.**

---

## 12. Historial y otras carpetas (referencia, no fuente)

| Versión | Dónde | Estado |
|---|---|---|
| Framer (en vivo) | indomitocafe.com | Metadata duplicada, `lang="en"`, 10 MB de fuentes (incluye SF Pro, sin licencia web), páginas de template indexadas, eventos vencidos, Club inventado |
| V1 React/Vite | `…/GoogleDrive…/MacStudio/IndomitoClaudeDesign/` | HashRouter (malo para SEO), `CLAUDE.md` y `shared.jsx` con datos falsos, `node_modules` sincronizado en Drive |
| V2 HTML | `/Users/xu/Work/indomito-website/` (raíz) | Buena voz; notas de diseño publicadas como copy, CTAs sin link, Club y Tienda dummy |
| Handoff de contenido | Perplexity, "Indómito Café — Content Handoff" | Estructura de 5 puertas y reglas de voz; precios inventados (no usar) |

Recomendación pendiente: mover V1, V2 y los checkpoints a `_archivo/`, fuera del alcance de los agentes, y reemplazar el `CLAUDE.md` de la V1 por uno con solo los hechos de la sección 2.


---

## 13. Archivo Sonoro

Sección `/archivo-sonoro/` con una página por escucha (`/archivo-sonoro/{artista-tema}/`). Código en `src/archivo.mjs`; datos en `src/archivo/archive.json`; imágenes en `src/archivo/img/` (tapas `cover-{id}-400|800.webp`, placas del Diario `diario-{fecha}-{id}.webp` recortadas al texto).

**Fuente:** export de `music_usage.sqlite3` del pipeline del Diario Sensorial (el mismo JSON que usa `archive-preview.diariosensorial.pages.dev`).

**Normalización en el build (no editar datos a mano):**
- Fecha: `editorial_date` (se quita el sufijo `_A`, `_B`…). Si falta, se usa el mes de `used_at` y se muestra como "mes de uso".
- Año del disco: `release_year`. Se descarta (se muestra "sin confirmar") si es anterior a 1920 o si contradice el año citado en la nota. El build lista esos casos en consola ("datos a revisar").
- Nota: se oculta si es el texto genérico "una entrada del archivo sonoro".
- Portada tipo `artist` se rotula "Foto del artista".

**Página índice:** búsqueda, décadas (según año del disco, generadas de los datos), "Una escucha al azar" (evento Umami `escucha-al-azar`).
**Ficha:** tapa, disco, año, fecha del Diario, nota si existe, publicación original (placa) si existe, "Seguí por acá" (hasta 3: mismo artista o disco a ±3 años). JSON-LD `MusicRecording`. Sin reproductor (decisión: pendiente).
**Home:** puerta "Archivo Sonoro" con las 3 últimas escuchas.

**Pendiente en el pipeline (Codex):**
1. Exportar sin `export_path`, `usage_id` ni `generated_from` (hoy publican rutas locales en el JSON de pages.dev).
2. Recuperar `editorial_date` de las 17 escuchas de abril–mayo 2026.
3. Revisar años en conflicto: Nils Frahm "Ambre" (2011 vs 2009), Bing & Ruth "Starwood Choker" (2020 vs 2015), Satie (1893).
4. Reemplazar las notas genéricas por notas reales o dejarlas vacías.
5. Al publicar una escucha nueva: copiar `archive.json` + imágenes a `src/archivo/`, correr `node build.mjs` y `npx wrangler deploy`.
