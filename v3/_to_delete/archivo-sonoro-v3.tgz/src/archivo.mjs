// Archivo Sonoro: normaliza el export del Diario Sensorial y genera sus páginas.
// Entrada: src/archivo/archive.json (export de music_usage.sqlite3). Imágenes: src/archivo/img/.
import fs from "node:fs";

const MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
const AÑO_MINIMO = 1920; // antes de esto, el dato es de composición, no del disco

const slugify = (t) => t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
const esc = (s = "") => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export function loadArchivo(file = "src/archivo/archive.json") {
  const raw = JSON.parse(fs.readFileSync(file, "utf8"));
  const revisar = [];
  const used = new Set();
  const entries = raw.items.map((it) => {
    // fecha: editorial exacta; si falta, mes de uso (used_at) marcado como aproximado
    const ed = (it.editorial_date || "").replace(/_[A-Z]+$/, "");
    const [y, m, d] = (ed || it.used_at.slice(0, 10)).split("-").map(Number);
    const exacta = Boolean(ed);
    const fechaLabel = exacta ? `${d} ${MESES[m - 1]} ${y}` : `${MESES[m - 1]} ${y}`;
    const orden = ed ? `${ed}T12:00` : it.used_at;
    // año del disco: descartar imposibles y contradicciones con la nota
    let año = /^\d{4}$/.test(it.release_year || "") ? Number(it.release_year) : null;
    if (año && año < AÑO_MINIMO) { revisar.push(`${it.artist} — ${it.track}: año ${año} parece de composición`); año = null; }
    const notaAño = (it.cover_note || "").match(/\((?:[^,()]+,\s*)?(\d{4})\)/);
    if (año && notaAño && Number(notaAño[1]) !== año) { revisar.push(`${it.artist} — ${it.track}: año ${año} y la nota dice ${notaAño[1]}`); año = null; }
    // nota: solo si dice algo
    const nota = /una entrada del archivo sonoro/i.test(it.cover_note || "") ? "" : (it.cover_note || "").trim();
    let slug = slugify(`${it.artist}-${it.track}`); while (used.has(slug)) slug += "-2"; used.add(slug);
    const base = (p) => (p ? p.split("/").pop().replace(/\.[a-z]+$/, "") : "");
    const coverStem = base(it.cover_path);
    const cover = it.cover_path?.endsWith(".svg") ? { svg: `cover-${coverStem}.svg` } : coverStem ? { s: `cover-${coverStem}-400.webp`, l: `cover-${coverStem}-800.webp` } : null;
    const slide = it.slide_path ? `diario-${it.slide_path.split("/").pop().replace(/\.[a-z]+$/, "")}.webp` : "";
    return {
      slug, artista: it.artist, tema: it.track, disco: it.album || "", año, fechaLabel, exacta, orden,
      nota, cover, coverTipo: it.cover_kind, coverLabel: it.cover_label || "", slide,
    };
  }).sort((a, b) => b.orden.localeCompare(a.orden));
  return { entries, revisar };
}

export function archivoPieces({ S, header, footer, trk }) {
  const { entries, revisar } = loadArchivo();
  const decadas = [...new Set(entries.filter((e) => e.año).map((e) => Math.floor(e.año / 10) * 10))].sort((a, b) => a - b);
  const href = (x, e) => (x.preview ? `#as-${e.slug}` : `/archivo-sonoro/${e.slug}/`);
  const img = (x, f) => (x.preview ? `archivo/${f}` : `/img/archivo/${f}`);
  const meta = (e) => [e.disco, e.año || "año sin confirmar"].filter(Boolean).join(" · ");

  const coverTag = (x, e, size = "s", eager = false) => {
    if (!e.cover) return `<div class="as-cover as-type" aria-hidden="true">${esc(e.artista)}</div>`;
    const alt = e.coverTipo === "artist" ? `Foto de ${e.coverLabel || e.artista}` : `Tapa de ${e.disco || e.tema}`;
    if (e.cover.svg) return `<img class="as-cover" src="${img(x, e.cover.svg)}" alt="${esc(alt)}" width="400" height="400"${eager ? "" : ' loading="lazy"'} decoding="async">`;
    return `<img class="as-cover" src="${img(x, size === "l" ? e.cover.l : e.cover.s)}" alt="${esc(alt)}" width="400" height="400"${eager ? "" : ' loading="lazy"'} decoding="async">`;
  };

  const card = (x, e) => `
<li class="as-card" data-decada="${e.año ? Math.floor(e.año / 10) * 10 : ""}" data-q="${esc(`${e.artista} ${e.tema} ${e.disco} ${e.año || ""}`.toLowerCase())}">
  <a href="${href(x, e)}">${coverTag(x, e)}
    <p class="k">${esc(e.fechaLabel)}</p>
    <p class="as-art">${esc(e.artista)}</p>
    <p class="as-tema">${esc(e.tema)}</p>
    <p class="as-meta">${esc(meta(e))}</p>
  </a>
</li>`;

  const homeBlock = (x) => `
<section class="door">
  <p class="k">Diario Sensorial</p>
  <div class="body">
    <h2>Archivo Sonoro</h2>
    <p>Las escuchas del Diario Sensorial, una por publicación.</p>
    <ul class="as-mini">${entries.slice(0, 3).map((e) => `<li><a href="${href(x, e)}">${coverTag(x, e)}<span><b>${esc(e.artista)}</b>${esc(e.tema)}</span></a></li>`).join("")}</ul>
    <a class="cta" href="${x.preview ? "#archivo-sonoro" : "/archivo-sonoro/"}">Explorar el archivo →</a>
  </div>
</section>`;

  const indexPage = {
    title: "Archivo Sonoro — Indómito",
    desc: `Las escuchas del Diario Sensorial de Indómito: ${entries.length} temas con su disco, año y fecha de publicación.`,
    body: (x) => `
<div class="wrap">
  <header class="ph intro"><p class="k">Diario Sensorial</p><h1>Archivo Sonoro</h1><p class="lead">Las escuchas del Diario Sensorial, una por publicación.</p></header>
  <div class="as-tools" data-as-tools>
    <label class="as-search" for="as-q"><span class="k">Buscar</span><input id="as-q" type="search" placeholder="Artista, tema o disco" autocomplete="off"></label>
    <div class="as-dec" role="group" aria-label="Año del disco">
      <button type="button" class="as-chip" data-dec="" aria-pressed="true">Todas</button>
      ${decadas.map((d) => `<button type="button" class="as-chip" data-dec="${d}" aria-pressed="false">${String(d).slice(2)}s</button>`).join("")}
    </div>
    <button type="button" class="cta as-rand" data-as-rand>Una escucha al azar →</button>
    <p class="as-count k" aria-live="polite" data-as-count>${entries.length} escuchas</p>
  </div>
  <ul class="as-grid" data-as-grid>${entries.map((e) => card(x, e)).join("")}</ul>
  <p class="as-empty" data-as-empty hidden>No hay escuchas para esa búsqueda.</p>
  <p class="notes">Década según el año del disco. Las fechas sin día corresponden al mes en que se usó el tema.</p>
</div>`,
  };

  const related = (e) => {
    const same = entries.filter((o) => o !== e && o.artista === e.artista).map((o) => [o, "Mismo artista"]);
    const near = entries.filter((o) => o !== e && o.artista !== e.artista && e.año && o.año && Math.abs(o.año - e.año) <= 3)
      .sort((a, b) => Math.abs(a.año - e.año) - Math.abs(b.año - e.año)).map((o) => [o, `Disco de ${o.año}`]);
    return [...same, ...near].slice(0, 3);
  };

  const entryPage = (e) => ({
    title: `${e.tema} — ${e.artista} · Archivo Sonoro — Indómito`,
    desc: e.nota || `${e.artista}, "${e.tema}"${e.disco ? ` (${e.disco}${e.año ? `, ${e.año}` : ""})` : ""}. Escucha del Diario Sensorial de Indómito, ${e.fechaLabel}.`,
    path: `/archivo-sonoro/${e.slug}/`,
    ld: { "@context": "https://schema.org", "@type": "MusicRecording", name: e.tema, byArtist: { "@type": "MusicGroup", name: e.artista }, ...(e.disco ? { inAlbum: { "@type": "MusicAlbum", name: e.disco } } : {}), url: `${S.url}/archivo-sonoro/${e.slug}/` },
    body: (x) => {
      const rel = related(e);
      return `
<div class="wrap">
  <header class="ph intro"><p class="k"><a href="${x.preview ? "#archivo-sonoro" : "/archivo-sonoro/"}">Archivo Sonoro</a> · ${esc(e.exacta ? e.fechaLabel : e.fechaLabel + " (mes de uso)")}</p><h1>${esc(e.tema)}</h1><p class="lead">${esc(e.artista)}</p></header>
  <section class="sec as-detail">
    <div>${coverTag(x, e, "l", true)}${e.coverTipo === "artist" ? `<p class="k mute" style="margin-top:10px">Foto del artista</p>` : ""}</div>
    <div class="stack">
      <dl class="ficha">
        <dt>Disco</dt><dd>${esc(e.disco || "Sin registrar")}</dd>
        <dt>Año</dt><dd>${e.año || "Sin confirmar"}</dd>
        <dt>Diario</dt><dd>${esc(e.fechaLabel)}${e.exacta ? "" : " · mes de uso"}</dd>
      </dl>
      ${e.nota ? `<p class="prose">${esc(e.nota)}</p>` : ""}
    </div>
  </section>
  ${e.slide ? `<section class="sec"><h2 class="k">Publicación original</h2><figure class="fig as-slide"><a href="${img(x, e.slide)}" target="_blank" rel="noopener"><img src="${img(x, e.slide)}" alt="Placa del Diario Sensorial: ${esc(e.artista)}, ${esc(e.tema)}." loading="lazy" decoding="async"></a></figure></section>` : ""}
  ${rel.length ? `<section class="sec"><h2 class="k">Seguí por acá</h2><ul class="as-grid as-rel">${rel.map(([o, why]) => `<li class="as-card"><a href="${href(x, o)}">${coverTag(x, o)}<p class="k">${esc(why)}</p><p class="as-art">${esc(o.artista)}</p><p class="as-tema">${esc(o.tema)}</p></a></li>`).join("")}</ul></section>` : ""}
</div>`;
    },
  });

  const JS = `
(function(){var t=document.querySelector('[data-as-tools]');if(!t)return;
var q=document.getElementById('as-q'),grid=document.querySelector('[data-as-grid]'),cards=[].slice.call(grid.children),count=document.querySelector('[data-as-count]'),empty=document.querySelector('[data-as-empty]'),dec='';
function apply(){var s=(q.value||'').trim().toLowerCase(),n=0;cards.forEach(function(c){var ok=(!dec||c.dataset.decada===dec)&&(!s||c.dataset.q.indexOf(s)>-1);c.hidden=!ok;if(ok)n++});count.textContent=n+(n===1?' escucha':' escuchas');empty.hidden=n>0}
q.addEventListener('input',apply);
t.querySelectorAll('.as-chip').forEach(function(b){b.addEventListener('click',function(){dec=b.dataset.dec;t.querySelectorAll('.as-chip').forEach(function(o){o.setAttribute('aria-pressed',String(o===b))});apply()})});
t.querySelector('[data-as-rand]').addEventListener('click',function(){var v=cards.filter(function(c){return !c.hidden});if(!v.length)return;var a=v[Math.floor(Math.random()*v.length)].querySelector('a');if(window.umami)umami.track('escucha-al-azar');location.href=a.getAttribute('href')});})();`;

  return { entries, revisar, homeBlock, indexPage, entryPage, JS };
}
