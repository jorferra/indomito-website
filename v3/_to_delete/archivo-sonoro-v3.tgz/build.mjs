// Indómito V3 — generador estático sin dependencias.
// Uso: node build.mjs  →  dist/ (sitio real) + preview/index.html (vista navegable)
import fs from "node:fs";
import path from "node:path";
import { archivoPieces } from "./src/archivo.mjs";

const C = JSON.parse(fs.readFileSync("content.json", "utf8"));
const S = C.site;
const CSS = fs.readFileSync("src/styles.css", "utf8");
const FONTS = `<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@500&display=swap">`;

const slug = (t) => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
const esc = (s = "") => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const ars = (n) => "$" + n.toLocaleString("es-AR");
const trk = (ev, origen) => ` data-umami-event="${ev}" data-umami-event-origen="${origen}"`;
const wa = (t) => `https://wa.me/${S.whatsapp}?text=${encodeURIComponent(t)}`;
const ig = (h) => `https://www.instagram.com/${h}`;

const ROUTES = {
  home: { path: "/", hash: "" },
  living: { path: "/living/", hash: "living" },
  carta: { path: "/carta/", hash: "carta" },
  sistema: { path: "/sistema-portatil/", hash: "sistema-portatil" },
  encuentros: { path: "/encuentros/", hash: "encuentros" },
  ls02: { path: "/encuentros/edicion-jamaica/", hash: "ls02" },
  tienda: { path: "/tienda/", hash: "tienda" },
  archivo: { path: "/archivo-sonoro/", hash: "archivo-sonoro" },
  origen: { path: "/origen/", hash: "origen" },
  terminos: { path: "/terminos/", hash: "terminos" },
};
const NAV = [["living", "Living"], ["carta", "Carta"], ["sistema", "Sistema Portátil"], ["encuentros", "Encuentros"], ["archivo", "Archivo Sonoro"], ["origen", "Origen"]];

function ctx(mode) {
  const preview = mode === "preview";
  return {
    preview,
    link: (r) => (preview ? "#" + (ROUTES[r].hash || "inicio") : ROUTES[r].path),
    src: (f) => (preview ? "img/" + f : "/img/" + f),
  };
}

// ---------- piezas ----------
const fig = (x, name, alt, cls = "r32", cap = "", eager = false) => `
<figure class="fig ${cls}">
  <img src="${x.src(name + "-1600.webp")}" srcset="${x.src(name + "-800.webp")} 800w, ${x.src(name + "-1600.webp")} 1600w" sizes="(max-width:860px) 100vw, 60vw" alt="${esc(alt)}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async">
  ${cap ? `<figcaption class="k mute">${esc(cap)}</figcaption>` : ""}
</figure>`;

const pill = (estado) => {
  const m = { convocatoria: ["Convocatoria abierta", ""], proximo: ["Próximo", ""], preparacion: ["En preparación", "hollow"], agotado: ["Agotado", "off"], archivo: ["Archivo", "off"], lista: ["Lista abierta", "hollow"] }[estado] || [estado, ""];
  return `<span class="pill ${m[1]}">${m[0]}</span>`;
};

const WORDMARK = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="70 -878 4238 883" aria-hidden="true" focusable="false"><path fill="currentColor" d="M70 0H159V-700H70Z M738 -700V-125L386 -700H299V0H378V-551L730 0H817V-700Z M1221 -701 957 -700V0H1221C1407 0 1475 -48 1475 -228V-473C1475 -653 1407 -702 1221 -701ZM1386 -228C1386 -118 1367 -63 1221 -63H1046V-638H1221C1367 -638 1386 -583 1386 -473Z M1803 -746H1882L2012 -878H1911ZM1854 5C2040 5 2113 -43 2113 -223V-475C2113 -655 2040 -703 1854 -703C1668 -703 1595 -655 1595 -475V-223C1595 -43 1668 5 1854 5ZM1854 -58C1708 -58 1684 -113 1684 -223V-475C1684 -585 1708 -640 1854 -640C2000 -640 2024 -585 2024 -475V-223C2024 -113 2000 -58 1854 -58Z M2797 -700 2569 -134 2338 -700H2243V0H2318V-530L2527 0H2595L2808 -541V0H2893V-700Z M3033 0H3122V-700H3033Z M3720 -700H3202V-634H3416V0H3505V-634H3720Z M4049 5C4235 5 4308 -43 4308 -223V-475C4308 -655 4235 -703 4049 -703C3863 -703 3790 -655 3790 -475V-223C3790 -43 3863 5 4049 5ZM4049 -58C3903 -58 3879 -113 3879 -223V-475C3879 -585 3903 -640 4049 -640C4195 -640 4219 -585 4219 -475V-223C4219 -113 4195 -58 4049 -58Z"/></svg>`;
const LS_FORMULA = "Una experiencia de Laboratorio Sensorial, en colaboración con Indómito Café.";

const header = (x, cur) => `
<header class="hd"><div class="wrap bar">
  <a class="brand" href="${x.link("home")}" aria-label="Indómito, inicio"><img class="mark-d" src="${x.src("disco.png")}" alt="" width="26" height="35"><img class="mark-l" src="${x.src("disco-light.png")}" alt="" width="26" height="35"><span class="wm-sm">${WORDMARK}</span></a>
  <nav class="nav" aria-label="Principal">${NAV.map(([r, l]) => `<a href="${x.link(r)}"${r === cur ? ' aria-current="page"' : ""}>${l}</a>`).join("")}</nav>
  <details class="mob"><summary>MENÚ</summary><nav class="sheet" aria-label="Principal móvil">${NAV.map(([r, l]) => `<a href="${x.link(r)}">${l}</a>`).join("")}</nav></details>
</div></header>`;

const footer = (x) => `
<footer class="ft"><div class="wrap grid">
  <div><p><strong>${S.name}</strong></p><p class="mute">${S.zona}</p><p class="mute">Respondemos nosotros, con tiempo.</p></div>
  <div>
    <p><a href="${ig(S.instagram)}" rel="noopener"${trk("instagram", "footer")}>Instagram · @${S.instagram}</a></p>
    <p><a href="${wa("Hola Indómito")}" rel="noopener"${trk("whatsapp", "footer")}>WhatsApp · ${S.whatsappLabel}</a></p>
    <p class="ft-tienda"><a href="${x.link("tienda")}">Tienda</a> <span class="mute">· ${esc(C.tienda.estadoLabel)}</span></p>
  </div>
  <div><p class="k mute">© ${S.year} ${S.name}</p><p><a class="mute" href="${x.link("terminos")}">Términos y privacidad</a></p></div>
</div></footer>`;

const AS = archivoPieces({ S, header, footer, trk });

const menuItems = (items) => items.map((i) => `
<div class="it"><span>${esc(i.nombre)}</span><span class="lead-dots" aria-hidden="true"></span><span class="pr">${ars(i.precio)}</span>${i.receta ? `<span class="rc">${esc(i.receta)}</span>` : ""}${i.nota ? `<span class="dt">${esc(i.nota)}</span>` : ""}</div>`).join("");

const allItems = C.carta.categorias.flatMap((c) => c.items);
const destacados = C.carta.destacados.map((n) => allItems.find((i) => i.nombre === n)).filter(Boolean);

const encCard = (x, e) => {
  const cta = e.cta ? `<a class="cta" href="${e.cta.href || wa(e.cta.wa)}" rel="noopener"${trk(e.cta.href ? "postulacion" : "lista", e.id)}>${e.cta.label}</a>` : "";
  const more = e.pagina ? `<a class="cta" href="${x.link(e.id)}">Ver edición →</a>` : "";
  return `
<article class="card">
  <p class="code">${esc(e.codigo)}</p>
  <div class="body">
    <h3>${esc(e.titulo)}</h3>${e.subtitulo ? `<p class="sub">${esc(e.subtitulo)}</p>` : ""}
    <p class="meta">${esc(e.fecha)}${e.nota ? " · " + esc(e.nota) : ""}</p>
    <p>${esc(e.bajada)}</p>
  </div>
  <div class="side">${e.estado === "archivo" ? "" : pill(e.estado)}${more}${cta}</div>
</article>`;
};

const aviso = (x) => {
  const e = C.encuentros.find((y) => y.estado === "convocatoria");
  if (!e) return "";
  return `<div class="aviso"><div class="wrap aviso-in">${pill(e.estado)}<a class="aviso-t" href="${x.link(e.id)}">${esc(e.nombreCompleto || e.titulo)}</a><a class="cta" href="${e.cta.href}" rel="noopener"${trk("postulacion", "aviso-home")}>${e.cta.label}</a></div></div>`;
};

// ---------- páginas ----------
const P = {};

P.home = {
  title: "Indómito — Café de especialidad en Caballito Norte",
  desc: "Un living a puertas cerradas en Caballito Norte. Café de especialidad, vinilos y encuentros con agenda. Barra de café portátil para eventos en CABA y GBA.",
  body: (x) => {
    const ls02 = C.encuentros.find((e) => e.id === "ls02");
    return `
${aviso(x)}
<section class="wrap hero">
  <div class="intro">
    <p class="k">Café de especialidad · Buenos Aires</p>
    <h1 class="wm"><span class="sr">Indómito</span>${WORDMARK}</h1>
    <p class="lead">Un living a puertas cerradas en Caballito Norte. Café, vinilos y encuentros.</p>
    <div class="row"><a class="cta" href="${x.link("encuentros")}">Ver encuentros →</a><a class="cta" href="${x.link("sistema")}">Sistema Portátil →</a></div>
  </div>
</section>

<div class="wrap">
<section class="door">
  <p class="k">Por convocatoria</p>
  <div class="body">
    <h2>Living</h2>
    <p>Abrimos cuando hay fecha. Pocos lugares, sin apuro.</p>
    <a class="cta" href="${x.link("living")}">Conocer el living →</a>
  </div>
</section>

<section class="door">
  <p class="k">Carta vigente · ${esc(C.carta.vigencia)}</p>
  <div class="body">
    <h2>Carta</h2>
    <p>Café de especialidad y pastelería artesanal.</p>
    <div class="menu mini">${menuItems(destacados.map((i) => ({ ...i, receta: "", nota: "" })))}</div>
    <p class="mute" style="margin-top:18px;font-size:var(--fs-sm)">${esc(C.carta.pie)}</p>
    <a class="cta" href="${x.link("carta")}">Ver carta completa →</a>
  </div>
</section>

<section class="door">
  <p class="k">Para eventos</p>
  <div class="body">
    <h2>Sistema Portátil</h2>
    <p>El café va donde vos estés. Especialidad, pastelería y música curada en un solo servicio.</p>
    <a class="cta" href="${x.link("sistema")}${x.preview ? "" : "#consulta"}">Consultar fecha →</a>
  </div>
</section>
</div>


<div class="wrap">
<section class="door">
  <p class="k">Agenda</p>
  <div class="body">
    <h2>Encuentros</h2>
    <p>Lo que pasó y lo que va a pasar.</p>
    <div class="stack state">
      <p class="row" style="gap:12px">${pill(ls02.estado)} <span>${esc(ls02.nombreCompleto)}</span></p>
      <p class="row" style="gap:12px">${pill("preparacion")} <span>Próxima apertura del living</span></p>
    </div>
    <a class="cta" href="${x.link("encuentros")}">Ver encuentros →</a>
  </div>
</section>
${AS.homeBlock(x)}

</div>`;
  },
};

P.living = {
  title: "Living a puertas cerradas en Caballito — Indómito",
  desc: "Café, vinilos y conversación en un living de Buenos Aires. Aperturas puntuales, con agenda, reserva o invitación.",
  body: (x) => {
    const L = C.living;
    const prox = L.estado === "sin-fecha"
      ? `<h3 style="margin-bottom:10px">Próxima apertura</h3><p>Estamos armando la próxima. Dejanos tu contacto y te avisamos.</p><a class="cta" style="margin-top:20px" href="${wa("Hola Indómito, quiero recibir la convocatoria del living.")}" rel="noopener"${trk("lista", "living")}>Anotarme por WhatsApp →</a>`
      : `<h3 style="margin-bottom:10px">Próxima apertura</h3><p class="big">${esc(L.proxima.dia)}</p><p class="mute">Caballito Norte · ${esc(L.proxima.horario)}</p><p class="mute">${esc(L.proxima.cupo)}</p><a class="cta" style="margin-top:20px" href="${wa("Hola Indómito, quiero reservar lugar para " + L.proxima.dia)}" rel="noopener">Reservar lugar →</a>`;
    return `
<div class="wrap">
  <header class="ph intro"><p class="k">Por convocatoria</p><h1>Living</h1><p class="lead">Café, vinilos y conversación.</p></header>
  <section class="sec split">
    <div><h2 class="k">Cómo funciona</h2></div>
    <ol class="steps"><li>Anunciamos la fecha.</li><li>Los lugares son pocos.</li><li>La dirección llega con la confirmación.</li></ol>
  </section>
  <section class="sec split">
    <div>${pill(L.estado === "sin-fecha" ? "preparacion" : "proximo")}</div>
    <div>${prox}</div>
  </section>
  <section class="sec">
    <h2 class="k">Archivo</h2>
    <p class="big" style="margin-bottom:32px">Lo que ya pasó.</p>
    ${L.archivo.map((a) => `
    <article class="split" style="padding-block:8px 24px">
      <div></div>
      <div class="stack">
        <p class="k mute">${esc(a.serie)}</p><h3>${esc(a.titulo)}</h3><p>${esc(a.nota)}</p>
        <div class="menu"><div class="it"><span>Café</span><span class="lead-dots"></span><span>${esc(a.cafe)}</span></div><div class="it"><span>Disco</span><span class="lead-dots"></span><span>${esc(a.musica)}</span></div></div>
      </div>
    </article>`).join("")}
  </section>
  <section class="sec"><p class="lema">${esc(L.frase)}</p></section>
</div>`;
  },
};

P.carta = {
  title: "Carta de café de especialidad — Indómito",
  desc: `Carta de Indómito: espresso, filtrados, fríos y pastelería. Precios vigentes, ${C.carta.vigencia.toLowerCase()}.`,
  body: (x) => `
<div class="wrap">
  <header class="ph intro"><p class="k">Carta vigente · ${esc(C.carta.vigencia)}</p><h1>Carta</h1><p class="lead">Café de especialidad y pastelería artesanal. Elegí sin apuro.</p><p class="mute" style="margin-top:14px;font-size:var(--fs-meta)">${esc(C.carta.notas[0])}</p>${x.preview ? "" : `<nav class="cat-index" aria-label="Categorías de la carta">${C.carta.categorias.map((c) => `<a href="#${slug(c.nombre)}">${esc(c.nombre)}</a>`).join("")}</nav>`}</header>
  <div class="bleed">${fig(x, "carta-granos", "Granos de café tostado.", "r219", "", true)}</div>
  <div class="cats">
    ${C.carta.categorias.map((c) => `<section class="cat" id="${x.preview ? "" : slug(c.nombre)}"><h2>${esc(c.nombre)}</h2>${c.meta ? `<p class="cmeta">${esc(c.meta)}</p>` : ""}<div class="menu">${menuItems(c.items)}</div></section>`).join("")}
  </div>
  <p class="k" style="display:block;padding-block:32px 8px;border-top:1px solid var(--line)">${esc(C.carta.pie)}</p>
  <div class="notes">${C.carta.notas.slice(1).map((n) => `<p>${esc(n)}</p>`).join("")}</div>
</div>`,
};

P.sistema = {
  title: "Barra de café para eventos en Buenos Aires — Indómito",
  desc: "Barra de café de especialidad, pastelería artesanal y música curada para lanzamientos, cenas y encuentros de marca. CABA y GBA.",
  body: (x) => `
<div class="wrap">
  <header class="ph intro"><p class="k">Para eventos</p><h1>Sistema Portátil</h1><p class="lead">El café va donde vos estés.</p></header>
  <section class="sec">
    <p class="big">Indómito se mueve. Molemos, preparamos y servimos el café en el momento, y la música viene con nosotros.</p>
  </section>
  <section class="sec">
    <h2 class="k">El sistema</h2>
    <dl class="ficha">
      <dt>Café</dt><dd>Especialidad. Espresso.</dd>
      <dt>Pastelería</dt><dd>Artesanal, dulce y salada.</dd>
      <dt>Música</dt><dd>Curaduría en vivo.</dd>
      <dt>Sonido</dt><dd>Equipo propio.</dd>
    </dl>
  </section>
  <section class="sec split">
    <div class="stack"><h2 class="k">Ocasiones</h2><p class="big">Para encuentros que merecen cuidado.</p></div>
    <div class="stack"><p style="font-size:var(--fs-bl)">Lanzamientos · Cenas · Activaciones · Encuentros de marca · Espacios culturales · Celebraciones privadas</p><p class="mute">CABA y GBA. Otras locaciones, a consultar.</p></div>
  </section>
  <section class="sec" id="consulta">
    <h2 class="k">Consultar disponibilidad</h2>
    <p class="big" style="margin-bottom:32px">Nos escribís con fecha y formato. Te respondemos, cerramos y vamos.</p>
    <form class="form" id="sp-form" novalidate>
      <label>Nombre<input id="sp-nombre" name="nombre" autocomplete="name" required aria-describedby="sp-err"><span id="sp-err" class="err" hidden>Escribí tu nombre para que sepamos a quién responder.</span></label>
      <label>WhatsApp<input id="sp-wa" name="whatsapp" inputmode="tel" autocomplete="tel"></label>
      <label>Fecha estimada<input id="sp-fecha" name="fecha" placeholder="Ej.: sábado 18 de octubre"></label>
      <label>Tipo de evento<select id="sp-tipo" name="tipo"><option>Lanzamiento</option><option>Cena</option><option>Activación</option><option>Encuentro de marca</option><option>Celebración privada</option><option>Otro</option></select></label>
      <label>Cantidad estimada de personas<input id="sp-personas" name="personas" inputmode="numeric"></label>
      <label>Zona<input id="sp-zona" name="zona" placeholder="Barrio o localidad"></label>
      <label class="full">Mensaje<textarea id="sp-msg" name="mensaje"></textarea></label>
      <button type="submit">Enviar consulta →</button>
    </form>
    <div class="done" id="sp-done" hidden>
      <p><strong>Tu consulta está lista.</strong></p>
      <p>Mandala por WhatsApp y seguimos por ahí.</p>
      <a class="cta" id="sp-link"${trk("consulta-sistema", "formulario")} href="${wa("Hola Indómito")}" rel="noopener">Abrir WhatsApp con la consulta →</a>
    </div>
  </section>
</div>`,
};

P.encuentros = {
  title: "Encuentros de café y vinilos — Indómito",
  desc: "Café, vinilos y conversación. Fechas puntuales y grupos reducidos, y ediciones de Laboratorio Sensorial.",
  body: (x) => {
    const vivos = C.encuentros.filter((e) => e.estado !== "archivo");
    const arch = C.encuentros.filter((e) => e.estado === "archivo");
    return `
<div class="wrap">
  <header class="ph intro"><p class="k">Agenda</p><h1>Encuentros</h1><p class="lead">Lo que pasó y lo que va a pasar.</p></header>
  <section style="padding-bottom:56px"><h2 class="k" style="margin-bottom:18px">Próximos</h2><div class="list">${vivos.map((e) => encCard(x, e)).join("")}</div></section>
  <section class="sec"><h2 class="k">Archivo</h2><div class="list">${arch.map((e) => encCard(x, e)).join("")}</div></section>
</div>`;
  },
};

P.ls02 = {
  title: "Laboratorio Sensorial: Edición Jamaica — Indómito",
  desc: "Seis estaciones de música jamaiquina sobre el proceso del café. Una experiencia de Laboratorio Sensorial, en colaboración con Indómito Café.",
  body: (x) => {
    const e = C.encuentros.find((y) => y.id === "ls02");
    const L = C.ls02;
    return `
<div class="wrap">
  <header class="ph intro"><p class="k"><a href="${x.link("encuentros")}">Encuentros</a> · Laboratorio Sensorial</p><h1>Edición Jamaica</h1><p class="lead">${esc(e.subtitulo)}. ${LS_FORMULA}</p></header>
  <section class="sec split">
    <div class="stack">${pill(e.estado)}<p class="k mute">${esc(e.fecha.replace("Laboratorio Sensorial · ",""))}</p></div>
    <div class="stack"><p class="big">${esc(L.lead2)}</p><p class="mute">${esc(L.fechaNota)}</p><a class="cta" href="${e.cta.href}" rel="noopener"${trk("postulacion", "pagina-edicion")}>${e.cta.label}</a></div>
  </section>
  <section class="sec split">
    <div><h2 class="k">La edición</h2></div>
    <div class="stack prose">${L.descripcion.map((t) => `<p>${esc(t)}</p>`).join("")}</div>
  </section>
  <section class="sec"><h2 class="k">Estaciones</h2><div class="stations">${L.estaciones.map((s, i) => `<div><b>${String(i + 1).padStart(2, "0")}</b><span>${s}</span></div>`).join("")}</div></section>
  <section class="sec split">
    <div><h2 class="k">Formato</h2></div>
    <ol class="steps">${L.formato.map((f) => `<li>${esc(f)}</li>`).join("")}</ol>
  </section>
  <section class="sec split">
    <div><h2 class="k">Créditos</h2></div>
    <div class="credits">${L.creditos.map((c) => `<div><p class="mute" style="font-size:var(--fs-meta)">${esc(c.rol)}</p><p style="font-size:var(--fs-bl);font-weight:600">${esc(c.nombre)}</p></div>`).join("")}<p class="mute" style="font-size:var(--fs-meta)"><a class="cta" href="${ig(S.instagramLS)}" rel="noopener">@${S.instagramLS} en Instagram →</a></p></div>
  </section>
</div>`;
  },
};

P.tienda = {
  title: "Tienda — Indómito",
  desc: "Café, prendas y objetos de tirada corta. La primera edición de Indómito está en preparación.",
  body: (x) => `
<div class="wrap">
  <header class="ph intro"><p class="k">Ediciones</p><h1>Tienda</h1><p class="lead">Lo disponible. Nada más.</p></header>
  <section class="sec split">
    <div class="stack">${pill("lista")}<p class="k mute">${esc(C.tienda.estadoLabel)}</p></div>
    <div class="stack"><p class="big">Café, prendas y objetos de tirada corta.</p><a class="cta" href="${wa("Hola Indómito, quiero recibir aviso cuando abra la Tienda.")}" rel="noopener"${trk("lista", "tienda")}>Anotarme por WhatsApp →</a></div>
  </section>
</div>`,
};

P.origen = {
  title: "Origen — Indómito",
  desc: "Indómito nació en un living de Caballito Norte: café de especialidad, vinilos, hospitalidad y encuentros que piden tiempo.",
  body: (x) => `
<div class="wrap">
  <header class="ph intro"><p class="k">El proyecto</p><h1>Origen</h1><p class="lead">Indómito nació en un living de Caballito Norte.</p></header>
  <div class="bleed">${fig(x, "origen-mano", "Mano preparando un espresso: el café molido en el portafiltro.", "r32", "", true)}</div>
  <section class="sec split">
    <div></div>
    <div class="stack" style="font-size:var(--fs-lead);line-height:1.55;max-width:40ch">
      <p>Entre vinilos, cafés, silencios y conversaciones que pedían más tiempo que likes.</p>
      <p>Después vino el oficio: moler, medir, esperar.</p>
      <p>El punto de partida sigue siendo el mismo: tiempo alrededor de la taza. Lo analógico, lo ritual, lo compartido.</p>
    </div>
  </section>
  <section class="sec"><p class="lema">Un café no se toma. Se habita.</p></section>
</div>`,
};

P.terminos = {
  title: "Términos y privacidad — Indómito",
  desc: "Términos de uso y tratamiento de datos del sitio de Indómito Café.",
  body: (x) => `
<div class="wrap">
  <header class="ph"><p class="k">Legal</p><h1 style="font-size:var(--fs-h2)">Términos y privacidad</h1></header>
  <section class="sec stack" style="max-width:64ch">
    <p>Este sitio tiene fines informativos y culturales. Los textos, imágenes y playlists publicados reflejan la identidad de Indómito y no pueden reproducirse sin autorización.</p>
    <p>No compartimos tus datos personales con terceros. Si nos escribís por WhatsApp o te anotás en una lista, usamos esa información solo para responderte o avisarte de nuevas fechas.</p>
    <p>El uso de este sitio implica la aceptación de estos términos. Podemos actualizarlos cuando haga falta.</p>
  </section>
</div>`,
};

P.archivo = AS.indexPage;

const P404 = {
  title: "Página no encontrada — Indómito",
  desc: "Esta página no existe.",
  body: (x) => `
<div class="wrap"><header class="ph"><p class="k">Error 404</p><h1>Página no encontrada</h1><p class="lead">Esto no está en la carta. La página que buscás no existe o cambió de lugar.</p><div class="row" style="margin-top:28px"><a class="cta" href="${x.link("home")}">Volver al inicio →</a><a class="cta" href="${x.link("carta")}">Ver la carta →</a></div></header></div>`,
};

// ---------- scripts ----------
const FORM_JS = `
(function(){var f=document.getElementById('sp-form');if(!f)return;f.addEventListener('submit',function(e){e.preventDefault();
var v=function(i){var el=document.getElementById(i);return el?el.value.trim():''};
var nombre=v('sp-nombre');var er=document.getElementById('sp-err');if(!nombre){er.hidden=false;document.getElementById('sp-nombre').focus();return}er.hidden=true;
var t='Hola Indómito, quiero consultar Sistema Portátil.\\n'+'Nombre: '+nombre+(v('sp-wa')?'\\nWhatsApp: '+v('sp-wa'):'')+(v('sp-fecha')?'\\nFecha: '+v('sp-fecha'):'')+'\\nTipo: '+v('sp-tipo')+(v('sp-personas')?'\\nPersonas: '+v('sp-personas'):'')+(v('sp-zona')?'\\nZona: '+v('sp-zona'):'')+(v('sp-msg')?'\\n'+v('sp-msg'):'');
document.getElementById('sp-link').href='https://wa.me/${S.whatsapp}?text='+encodeURIComponent(t);
f.hidden=true;var d=document.getElementById('sp-done');d.hidden=false;d.querySelector('a').focus();if(window.umami){umami.track('consulta-sistema',{tipo:v('sp-tipo'),personas:v('sp-personas')})}if(window.top===window.self){window.location.href=document.getElementById('sp-link').href}});})();
(function(){document.querySelectorAll('.mob .sheet a').forEach(function(a){a.addEventListener('click',function(){var d=a.closest('details');if(d)d.open=false})})})();`;

const ROUTER_JS = `
(function(){var titles=${JSON.stringify({ ...Object.fromEntries(Object.entries(ROUTES).map(([k, r]) => [r.hash || "inicio", P[k].title])), ...Object.fromEntries(AS.entries.map((e) => ["as-" + e.slug, AS.entryPage(e).title])) })};
function go(){var h=(location.hash||'#inicio').slice(1)||'inicio';var pages=document.querySelectorAll('[data-page]');var hit=false;
pages.forEach(function(p){var on=p.getAttribute('data-page')===h;p.hidden=!on;if(on)hit=true});
if(!hit){document.querySelector('[data-page="inicio"]').hidden=false;h='inicio'}
document.title=titles[h]||titles.inicio;window.scrollTo(0,0);
document.querySelectorAll('.mob').forEach(function(d){d.open=false});}
window.addEventListener('hashchange',go);go();})();`;

// ---------- salida ----------
const head = (k, pg) => {
  const url = S.url + (pg.path || (ROUTES[k] ? ROUTES[k].path : "/404"));
  const ld = k === "home" ? `<script type="application/ld+json">${JSON.stringify({ "@context": "https://schema.org", "@type": "CafeOrCoffeeShop", name: S.name, url: S.url + "/", image: S.url + "/img/og.jpg", telephone: "+" + S.whatsapp, address: { "@type": "PostalAddress", addressLocality: "Caballito", addressRegion: "CABA", addressCountry: "AR" }, areaServed: "Buenos Aires", servesCuisine: "Café de especialidad", sameAs: [ig(S.instagram)] })}</script>` : "";
  return `<!doctype html>
<html lang="es-AR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(pg.title)}</title>
<meta name="description" content="${esc(pg.desc)}">
${k === "404" ? '<meta name="robots" content="noindex">' : `<link rel="canonical" href="${url}">`}
<meta property="og:type" content="website"><meta property="og:locale" content="es_AR"><meta property="og:site_name" content="${S.name}">
<meta property="og:title" content="${esc(pg.title)}"><meta property="og:description" content="${esc(pg.desc)}"><meta property="og:url" content="${url}"><meta property="og:image" content="${S.url}/img/og.jpg">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)"><meta name="theme-color" content="#14120f" media="(prefers-color-scheme: dark)">
<link rel="icon" href="/img/favicon.png" type="image/png"><link rel="apple-touch-icon" href="/img/apple-touch-icon.png">
${FONTS}
<link rel="stylesheet" href="/styles.css">
${S.umami ? `<script defer src="${S.umami.src}" data-website-id="${S.umami.id}"></script>` : ""}
${ld}${pg.ld ? `<script type="application/ld+json">${JSON.stringify(pg.ld)}</script>` : ""}
</head>
<body>`;
};

function buildDist() {
  fs.rmSync("dist", { recursive: true, force: true });
  const x = ctx("dist");
  const write = (p, html) => { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, html); };
  for (const [k, r] of Object.entries(ROUTES)) {
    const pg = P[k];
    write(path.join("dist", r.path, "index.html"), `${head(k, pg)}\n${header(x, k)}\n<main>${pg.body(x)}</main>\n${footer(x)}\n<script src="/site.js" defer></script>\n</body>\n</html>\n`);
  }
  write("dist/404.html", `${head("404", P404)}\n${header(x, "")}\n<main>${P404.body(x)}</main>\n${footer(x)}\n</body>\n</html>\n`);
  write("dist/styles.css", CSS);
  for (const e of AS.entries) {
    const pg = AS.entryPage(e);
    write(path.join("dist", pg.path, "index.html"), `${head("archivo-entry", pg)}\n${header(x, "archivo")}\n<main>${pg.body(x)}</main>\n${footer(x)}\n<script src="/site.js" defer></script>\n</body>\n</html>\n`);
  }
  write("dist/site.js", FORM_JS + AS.JS);
  fs.cpSync("src/img", "dist/img", { recursive: true });
  fs.cpSync("src/archivo/img", "dist/img/archivo", { recursive: true });
  write("dist/robots.txt", `User-agent: *\nAllow: /\n\nSitemap: ${S.url}/sitemap.xml\n`);
  write("dist/sitemap.xml", `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${[...Object.values(ROUTES).map((r) => r.path), ...AS.entries.map((e) => `/archivo-sonoro/${e.slug}/`)].map((u) => `  <url><loc>${S.url}${u}</loc></url>`).join("\n")}\n</urlset>\n`);
  write("dist/_redirects", [
    "# URLs del sitio en Framer → V3",
    "/eventos /encuentros/ 301",
    "/objetos /tienda/ 301",
    "/club /encuentros/ 301",
    "/club/tg1 /living/ 301",
    "/club/playlists /origen/ 301",
    "/terms /terminos/ 301",
    "# /news, /page-3, /old-home-2, /tcvxp y /index.php/* quedan en 404 a propósito: son restos de template y de un sitio anterior.",
    "",
  ].join("\n"));
}

function buildPreview() {
  const x = ctx("preview");
  const pages = Object.entries(ROUTES).map(([k, r]) => `<div data-page="${r.hash || "inicio"}"${k === "home" ? "" : " hidden"}>\n${header(x, k)}\n<main>${P[k].body(x)}</main>\n${footer(x)}\n</div>`).join("\n")
    + AS.entries.map((e) => `<div data-page="as-${e.slug}" hidden>\n${header(x, "archivo")}\n<main>${AS.entryPage(e).body(x)}</main>\n${footer(x)}\n</div>`).join("\n");
  const html = `<title>Indómito V3</title>
${FONTS}
<style>
${CSS}
</style>
${pages}
<script>${FORM_JS}${AS.JS}${ROUTER_JS}</script>
`;
  fs.mkdirSync("preview", { recursive: true });
  fs.writeFileSync("preview/index.html", html);
}

buildDist();
buildPreview();
if (AS.revisar.length) console.log("Archivo Sonoro, datos a revisar:\n  - " + AS.revisar.join("\n  - "));
console.log("OK · dist/ y preview/index.html");
